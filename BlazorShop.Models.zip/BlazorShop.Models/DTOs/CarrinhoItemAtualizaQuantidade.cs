﻿namespace BlazorShop.Models.DTOs
{
    public class CarrinhoItemAtualizaQuantidade
    {
        public int CarrinhoItemId { get; set; }
        public int Quantidade { get; set; }
    }
}
